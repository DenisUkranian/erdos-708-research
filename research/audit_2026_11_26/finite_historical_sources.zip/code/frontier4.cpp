// Exact four-dimensional Pareto frontier after taking k distinct source values.
// Each coordinate uses one byte, high byte first for lexicographic sorting.
// For the shipped ranges a coordinate is at most 9*floor(log2(28812)) < 128.
#include <array>
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using Key=uint32_t;
int byte(Key k,int i){return (k>>(8*(3-i)))&255;}
std::vector<Key> reduce(std::vector<Key> values) {
    std::sort(values.begin(),values.end(),std::greater<Key>());
    values.erase(std::unique(values.begin(),values.end()),values.end());
    int ymax=2,zmax=2;
    for(Key x:values){ymax=std::max(ymax,2+byte(x,1));zmax=std::max(zmax,2+byte(x,2));}
    std::vector<int> tree((ymax+1)*(zmax+1),-1);
    std::vector<Key> out;
    for(Key x:values){
        int y=ymax-byte(x,1), z=zmax-byte(x,2), best=-1;
        for(int a=y;a;a-=a&-a)for(int b=z;b;b-=b&-b)
            best=std::max(best,tree[a*(zmax+1)+b]);
        if(best>=byte(x,3))continue;
        out.push_back(x);
        for(int a=y;a<=ymax;a+=a&-a)for(int b=z;b<=zmax;b+=b&-b)
            tree[a*(zmax+1)+b]=std::max(tree[a*(zmax+1)+b],byte(x,3));
    }
    return out;
}
int main(){
    int k;std::cin>>k;std::vector<std::vector<Key>> dp(k+1);dp[0]={0};
    int x;while(std::cin>>x){
        Key v=x;
        for(int i=1;i<4;i++){std::cin>>x;v=(v<<8)+x;}
        for(int j=k;j>=1;j--){
            std::vector<Key> next=dp[j];
            for(Key a:dp[j-1]){
                for(int i=0;i<4;i++)assert(byte(a,i)+byte(v,i)<128);
                next.push_back(a+v);
            }
            dp[j]=reduce(std::move(next));
        }
    }
    for(Key x:dp[k])std::cout<<byte(x,0)<<" "<<byte(x,1)<<" "<<byte(x,2)<<" "<<byte(x,3)<<"\n";
}
