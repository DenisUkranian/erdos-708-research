from arithmetic import factors,divisors
for n,t,r,P,s in [(7,9,6,7,7),(8,11,8,7,9),(9,12,9,11,10)]:
    # A divisibility-minimal divisor >= r+2 divides a product built at its first crossing.
    cap=(r+1)*P
    minimal=[a for a in range(r+2,cap+1)
             if max(factors(a))<=P and all(d<r+2 for d in divisors(a)[:-1])]
    assert max(minimal)==49
    print(n,minimal,'pair threshold',t*49**2)
    from itertools import permutations,product
    def pair_cost(a,b):
        return min(k*d*e for i,j,k in permutations((t-2,t-1,t))
                   for d in divisors(a) if d>=i for e in divisors(b) if e>=j)
    bound=max(pair_cost(a,b) for a,b in product(minimal,repeat=2))
    assert bound=={7:4375,8:21609,9:24010}[n]
    print("best ordered worst-pair threshold",bound)
    if n==8:
        assert {(a,b) for a,b in product(minimal,repeat=2) if pair_cost(a,b)>11025}=={(35,49),(49,35),(49,49)}
        assert pair_cost(35,49)==15435
    if n==9:
        assert [(a,b) for a,b in product(minimal,repeat=2) if pair_cost(a,b)>20000]==[(49,49)]
    if n==7:
        assert {(a,b) for a,b in product(minimal,repeat=2) if pair_cost(a,b)>2500}=={(25,25),(15,25),(25,15),(49,49)}
        assert [(a,b) for a,b in product(minimal,repeat=2) if pair_cost(a,b)>2744]==[(25,25)]
assert max(3*7**3,2*6**4,7**4,9*7*49)<=4375
assert max(2*9**4,3*9**3)<=21609
assert max(2*10**4,3*9**4,2*3200,16000,12*10*49,21609)<=24010

assert 6**4*2<2744 and 7**4<=2744 and 8*7*49==2744

assert max(2*8**4,3*8**3,9**4,2*9**3,11*9*49)<=11025
assert max(2*10**4,3*9**4,2*3200,16000,12*10*49,11025)<=20000
