"""Check all inequalities in the prime-power refinements of the analytical tails."""
from arithmetic import factors

def supply(L,h,p):
    m=L//h
    result=m*factors(h).count(p)
    while m:
        m//=p
        result+=m
    return result

def upper_after_deletion(L,p,large_min,t,count,deleted):
    # Each source with v_p>=3 has small part a pure power of p in the group under
    # consideration. Two rough factors cannot coexist with p^3 > t.
    e=3
    list_e=[]
    while p**e<=L:
        list_e.append(e)
        for q in range(large_min,L//(p**e)+1):
            if len(factors(q))==1 and t*q*q>L:
                list_e.append(e)
        e+=1
    list_e+=([2]*count)
    return sum(sorted(list_e,reverse=True)[deleted:count])

for low,stop,n,p,t,large,count,deleted,h,extra in [
    (2500,2744,7,5,9,11,7,2,625,4),
    (2500,2744,7,5,9,11,6,1,375,3),
    (2744,4375,7,5,9,11,7,2,625,4),
    (11025,15435,8,7,11,11,7,1,1715,3),
    (11025,21609,8,7,11,11,8,2,2401,4),
    (20000,24010,9,7,12,13,9,2,2401,4),
]:
    min_margin=min(supply(L,h,p)-extra-upper_after_deletion(L,p,large,t,count,deleted)
                   for L in range(low,stop))
    assert min_margin>=0
    if h==1715:assert min(supply(L,h,5) for L in range(low,stop))>=7
    print(n,h,low,stop-1,'min valuation margin',min_margin)
