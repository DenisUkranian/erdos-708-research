#!/usr/bin/env python3
"""Reconstruct reduction domains and check proof DAGs for each row. Python 3.10+, C++17."""
import argparse
import gzip
import json
import subprocess
import tempfile
from pathlib import Path
from itertools import combinations,product
from collections import Counter
from arithmetic import *
from check_dag import verify

HERE=Path(__file__).resolve().parent
SMALL=(2,3,5,7)
BUDGET={7:9,8:11,9:12}
TAIL={7:21609,8:26411,9:28812}

def smooth_rows(n, fast=None, shard=0, parts=1):
    t=BUDGET[n];ps=SMALL
    nums=smooth_values(TAIL[n]-1,ps)
    for idx,M in enumerate(nums):
        if idx%parts!=shard:continue
        if M<=t or len(factors(M))<2:continue
        c=[a for a in nums if a<M and a*t>M and len(factors(a))>=2 and not removable_pair(a,M,M,t)]
        if len(c)<n-1 or rough_envelope(M,c,n,ps,t):continue
        if fast:
            # A surviving n-set is a clique of incompatible deletions. M is fixed.
            while c:
                trimmed=[a for a in c if sum(a!=b and not removable_pair(a,b,M,t) for b in c)>=n-2]
                if trimmed==c:break
                c=trimmed
            if len(c)<n-1:continue
            inp=str(n-1)+'\n'+''.join(' '.join(map(str,exponent_vector(a,ps)))+'\n' for a in c)
            out=subprocess.run([str(fast)],input=inp,text=True,capture_output=True,check=True)
            em=exponent_vector(M,ps)
            vs=[tuple(a+b for a,b in zip(map(int,s.split()),em)) for s in out.stdout.splitlines()]
        else:
            vs=source_frontier([exponent_vector(a,ps) for a in c],n-1,exponent_vector(M,ps))
        yield M,ps,vs

def source_sums(pool,count,M,ps):
    must=M in pool
    k=count-int(must)
    if k<0 or count>len(pool):return set()
    dp=[{0}]+[set() for _ in range(k)]
    for a in pool:
        if a==M:continue
        val=pack_key(exponent_vector(a,ps))
        for j in range(k,0,-1):
            dp[j].update(z+val for z in dp[j-1])
    inc=pack_key(exponent_vector(M,ps)) if must else 0
    return {z+inc for z in dp[k]}

def local_rows(n,top=120):
    t=BUDGET[n]; small=SMALL if n<=8 else SMALL+(11,)
    d=4 if n==8 else 3
    for M in range(t+1,top+1):
        if len(factors(M))<2:continue
        c=[a for a in range(2,M+1) if a*t>M and len(factors(a))>=2 and (a==M or not removable_pair(a,M,M,t))]
        other=set(p for a in c for p in factors(a) if p not in small)
        assert all(p*q>M for p in other for q in other)
        groups={p:[a for a in c if a%p==0] for p in other}
        base=[a for a in c if not set(factors(a))-set(small)]
        available=sorted(p for p in other if len(groups[p])>=d)
        for size in range(n//d+1):
            for qs in combinations(available,size):
                ps=small+qs
                if set(factors(M))-set(ps):continue
                if not qs and n<=8:continue # already in smooth_rows
                if not qs and n==9 and 11 not in set(p for a in base for p in factors(a)):continue
                sums=set()
                for counts in product(*(range(d,min(n,len(groups[p]))+1) for p in qs)):
                    k=n-sum(counts)
                    if not 0<=k<=len(base):continue
                    s=source_sums(base,k,M,ps)
                    for p,j in zip(qs,counts):
                        z=source_sums(groups[p],j,M,ps)
                        s={u+v for u in s for v in z}
                    sums.update(s)
                if sums:yield M,ps,(unpack_key(z,ps) for z in sums)

def conditional_rows():
    # Condition g(8)<=11; two friendly factors reduce all sufficiently large M.
    ps=SMALL+(11,)
    for M in range(14,13*11*11):
        def hard(a):
            return not any(eligible_step(12,u,M) and eligible_step(13,a//u,M) for u in divisors(a))
        if not hard(M):continue
        c=[a for a in range(2,M+1) if hard(a)]
        if len(c)<9:continue
        assert all(set(factors(a))<=set(ps) for a in c)
        yield M,ps,(unpack_key(z,ps) for z in source_sums(c,9,M,ps))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('part',choices=['smooth','local','conditional','mixed'])
    parser.add_argument('n',type=int,choices=[7,8,9])
    parser.add_argument('--shard',type=int,default=0)
    parser.add_argument('--parts',type=int,default=1)
    parser.add_argument('--lo',type=int,default=121)
    parser.add_argument('--hi',type=int,default=180)
    parser.add_argument('--export',type=Path,help='Optional gzip archive of all validated DAG rows')
    args=parser.parse_args()
    n=args.n
    if args.part=='conditional':assert n==9
    t=13 if args.part=='conditional' else BUDGET[n]
    from mixed_range import rows as mixed_rows
    assert args.parts>=1 and 0<=args.shard<args.parts
    domain={'mixed':lambda:mixed_rows(n,args.lo,args.hi),'smooth':lambda:smooth_rows(n),'local':lambda:local_rows(n),'conditional':conditional_rows}[args.part]()
    stats=Counter(); fallback=set()
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        for name in ('recipes','residues','frontier4'):
            subprocess.run(['g++','-O3','-std=c++17',str(HERE/(name+'.cpp')),'-o',str(tmp/name)],check=True)
        if args.part=='smooth' and n==9:
            domain=smooth_rows(n,tmp/'frontier4',args.shard,args.parts)
        else:assert args.parts==1
        cert_file=gzip.open(args.export,'wt') if args.export else None
        for M,ps,vecs in domain:
            stats['rows']+=1
            tab=prime_tables(M,ps,t)
            bad=[]
            for v in vecs:
                stats['input_vectors']+=1
                if sum(c[e] for c,e in zip(tab,v))<=t:continue
                bad.append(v)
            if args.part!='smooth':bad=maximal_by_tail(bad)
            bad=[v for v in bad if not simple_slots(v,ps,M,t)]
            if not bad:continue
            inp=' '.join(map(str,(len(ps),t,*ps)))+'\n'+''.join(' '.join(map(str,(M,*v)))+'\n' for v in bad)
            out=subprocess.run([str(tmp/'recipes'),str(tmp/'dag')],input=inp,text=True,capture_output=True,check=True)
            with (tmp/'dag').open() as f:roots=verify(f,ps,t)
            misses={tuple(map(int,line.split()[1:])) for line in out.stdout.splitlines()}
            assert roots=={(M,pack_key(v)) for v in bad if v not in misses}
            for v in misses:
                assert all(e==0 for e in v[3:]),(M,ps,v)
                fallback.add((M,t,*v[:3]))
            if cert_file:
                cert_file.write('primes '+' '.join(map(str,ps))+'\n')
                cert_file.write((tmp/'dag').read_text())
            stats['recipe_roots']+=len(roots)
        if cert_file:cert_file.close()
        inp=''.join(' '.join(map(str,row))+'\n' for row in sorted(fallback))
        out=subprocess.run([str(tmp/'residues')],input=inp,text=True,capture_output=True,check=True)
        checks=[list(map(int,s.split())) for s in out.stdout.splitlines()]
        assert len(checks)==len(fallback)
    print(json.dumps({'part':args.part,'n':n,'bound':t,'shard':args.shard,'parts':args.parts,'status':'PASS','counts':stats,
                      'residue_checks_M_e2_e3_e5_period_max_used':checks},indent=2))

if __name__=='__main__':main()
