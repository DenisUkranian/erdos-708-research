"""Exact mixed-prime source generator for a further range of maxima."""
from collections import defaultdict
from itertools import combinations
from arithmetic import *
def rows(n,lo,hi):
    # n=7 only; d>=3, at most three active primes >=11 by the archived reduction.
    assert n==7
    t=9
    small=(2,3,5,7)
    for M in range(lo,hi+1):
        if M<=t or len(factors(M))<2:continue
        c=[a for a in range(2,M+1) if a*t>M and len(factors(a))>=2 and (a==M or not removable_pair(a,M,M,t))]
        supports={a:frozenset(p for p in factors(a) if p not in small) for a in c}
        large=sorted(p for p in set().union(*supports.values()) if t*p*p>M and sum(p in s for s in supports.values())>=3)
        for k in range(1,4):
            for Q in combinations(large,k):
                if not supports[M].issubset(Q):continue
                pool=[a for a in c if supports[a].issubset(Q)]
                if len(pool)<n or sum(sorted((len(supports[a]) for a in pool),reverse=True)[:n])<3*k:continue
                if any(sum(p in supports[a] for a in pool)<3 for p in Q):continue
                # Attach a small counter for source support to each prime's valuation.
                ps=small+Q
                b=len(ps)*8
                def encoded(a):
                    return pack_key(exponent_vector(a,ps))+sum(1<<(b+4*i) for i,p in enumerate(Q) if p in supports[a])
                # Split by core membership; domains with high support have many forced choices.
                groups=defaultdict(list)
                for a in pool:
                    if a!=M:groups[supports[a]].append(encoded(a))
                groups=sorted(groups.items(),key=lambda entry:len(entry[0]),reverse=True)
                def enumerate_counts(i,left,counts,log):
                    if i==len(groups):
                        if left==0 and all(x>=3 for x in counts):yield log
                        return
                    S,group=groups[i]
                    for j in range(min(left,len(group))+1):
                        new=tuple(x+(j if p in S else 0) for p,x in zip(Q,counts))
                        if any(x+left-j<3 for x in new):continue
                        yield from enumerate_counts(i+1,left-j,new,log+(j,))
                sub={}
                def choices(i,k):
                    if (i,k) not in sub:
                        dp=[{0}]+[set() for _ in range(k)]
                        for val in groups[i][1]:
                            for j in range(k,0,-1):dp[j].update(z+val for z in dp[j-1])
                        sub[i,k]=dp[k]
                    return sub[i,k]
                sums=set()
                for ks in enumerate_counts(0,n-1,tuple(int(p in supports[M]) for p in Q),()):
                    vals={encoded(M)}
                    for i,num in enumerate(ks):
                        if num:vals={a+v for a in vals for v in choices(i,num)}
                    sums.update(v% (1<<b) for v in vals)
                if sums:yield M,ps,(unpack_key(z,ps) for z in sums)
