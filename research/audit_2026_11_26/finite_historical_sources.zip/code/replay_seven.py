"""Validate the stored seven-source DAG and compare its root set with the reduction."""
from pathlib import Path
import gzip
from arithmetic import prime_tables,simple_slots,pack_key
from check_dag import verify
from verify import smooth_rows
HERE=Path(__file__).resolve().parent
proved=set()
with gzip.open(HERE.parent/'records/smooth7.dag.gz','rt') as f:
    lines=[]
    for line in f:
        if line.startswith('primes '):
            if lines:proved.update(verify(lines,ps,9))
            ps=tuple(map(int,line.split()[1:]));assert ps==(2,3,5,7)
            lines=[]
        else:lines.append(line)
    if lines:proved.update(verify(lines,ps,9))
expected=set()
for M,ps,vecs in smooth_rows(7):
    cap=prime_tables(M,ps,9)
    for v in vecs:
        if sum(c[e] for c,e in zip(cap,v))>9 and not simple_slots(v,ps,M,9):
            expected.add((M,pack_key(v)))
direct={(27,pack_key(e)) for e in ((13,9,0,0),(11,10,0,0))}
assert proved.isdisjoint(direct) and expected==proved|direct
print('PASS / stored DAG roots:',len(proved),'/ remaining CRT roots:',len(direct))
