#!/usr/bin/env python3
"""Exact minimum for one positive interval. Can be expensive for large demands."""
import argparse
from collections import Counter
from math import gcd,prod
from arithmetic import factors

def exact(A,x):
    assert x>=0 and len(set(A))==len(A) and min(A)>=2
    M=max(A)
    P=prod(A)
    # Coverage state is the already supplied divisor of P. Save the actual offsets.
    best={1:()}
    for j in range(1,M+1):
        h=gcd(P,x+j)
        if h==1:continue
        for d,selected in tuple(best.items()):
            new=d*gcd(P//d,h)
            if new!=d and (new not in best or len(selected)+1<len(best[new])):
                best[new]=selected+(j,)
    assert P in best and prod(x+j for j in best[P])%P==0
    return best[P]

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--x',type=int,required=True,help='interval is x+1 through x+max(A)')
    parser.add_argument('A',nargs='+',type=int)
    args=parser.parse_args()
    offsets=exact(args.A,args.x)
    print('tau',len(offsets),'offsets',*offsets)
