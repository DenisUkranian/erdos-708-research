"""Integer predicates used by the finite reduction. No external dependencies."""
from collections import defaultdict
from functools import cache
from itertools import permutations
from math import prod

@cache
def factors(a):
    for p in range(2, a+1):
        if p*p>a:
            break
        if a%p==0:
            return (p,)+factors(a//p)
    return (a,) if a>1 else ()

@cache
def divisors(a):
    values={1}
    for p in factors(a):
        values.update([p*x for x in values])
    return sorted(values)

def smooth_values(limit, primes):
    values=[1]
    for p in primes:
        out=[]
        for a in values:
            while a<=limit:
                out.append(a)
                a*=p
        values=out
    return sorted(x for x in values if x>=2)

def exponent_vector(a, primes):
    return tuple(factors(a).count(p) for p in primes)

def eligible_step(j,h,M):
    return j*h<=M or len(factors(h))<=1

@cache
def first_divisor(a,j,M):
    return next(d for d in divisors(a) if eligible_step(j,a//d,M))

def removable_pair(a,b,M,t):
    for i,j,k in permutations((t-2,t-1,t)):
        d=first_divisor(a,i,M)
        e=first_divisor(b,j,M)
        if eligible_step(k,d*e,M):
            return True
    return False

def skyline4(points):
    """Exact orthant maxima in four dimensions, with a prefix-maximum Fenwick tree."""
    pts=sorted(set(points),reverse=True)
    if not pts:
        return []
    h1=max(x[1] for x in pts)+2
    h2=max(x[2] for x in pts)+2
    tree=[[-1]*(h2+1) for _ in range(h1+1)]
    out=[]
    for x in pts:
        a,b=h1-x[1],h2-x[2]
        best=-1
        i=a
        while i:
            j=b
            while j:
                best=max(best,tree[i][j])
                j-=j&-j
            i-=i&-i
        if best>=x[3]:
            continue
        out.append(x)
        i=a
        while i<=h1:
            j=b
            while j<=h2:
                tree[i][j]=max(tree[i][j],x[3])
                j+=j&-j
            i+=i&-i
    return out

def maximal_by_tail(points):
    """Keep the last coordinates fixed. Extra undominated points only cost time."""
    groups=defaultdict(list)
    for x in points:
        groups[x[4:]].append(x[:4])
    return [p+tail for tail,group in groups.items() for p in skyline4(group)]

def source_frontier(pool, take, max_vector):
    dp=[[tuple(0 for _ in max_vector)]]+[[] for _ in range(take)]
    for idx,v in enumerate(pool,1):
        for j in range(min(take,idx),0,-1):
            add=[tuple(a+b for a,b in zip(u,v)) for u in dp[j-1]]
            dp[j]=skyline4(dp[j]+add)
    return [tuple(a+b for a,b in zip(u,max_vector)) for u in dp[-1]]

def prime_tables(M,primes,t):
    result=[]
    for p in primes:
        layers=[]
        q=M//p
        while q:
            layers.append(q)
            q//=p
        cap=[sum(min(k,z) for z in layers) for k in range(t+1)]
        result.append([next((k for k,y in enumerate(cap) if y>=e),t+1) for e in range(128)])
    return result

def simple_slots(e,primes,M,t):
    caps=[M//j for j in range(1,t+1)]
    terms=[p for p,a in zip(primes,e) for _ in range(a)][::-1]
    for mode in (0,1,2):
        bins=[1]*t
        for p in terms:
            found=[j for j in range(t) if p*bins[j]<=caps[j]]
            if not found:break
            j=found[0]
            for k in found[1:]:
                if (mode==1 and caps[k]*bins[j]<caps[j]*bins[k]) or (mode==2 and caps[k]*bins[j]>caps[j]*bins[k]):
                    j=k
            bins[j]*=p
        else:
            assert all((i+1)*h<=M for i,h in enumerate(bins))
            assert prod(bins)==prod(p**a for p,a in zip(primes,e))
            return True
    return False

def rough_envelope(M,pool,n,primes,t):
    if primes[-1]*t>M:return False
    def rough(a,p):return prod(q for q in factors(a) if q>=p)
    for p in primes:
        upper=rough(M,p)*prod(sorted((rough(a,p) for a in pool),reverse=True)[:n-1])
        fail=p*prod(max(M//(p*j)+1,p) for j in range(1,t+1))
        if upper>=fail:return False
    return True

def pack_key(e):
    assert all(0<=v<128 for v in e)
    return sum(v<<(8*i) for i,v in enumerate(e))

def unpack_key(k,ps):
    return tuple((k>>(8*i))&255 for i in range(len(ps)))
