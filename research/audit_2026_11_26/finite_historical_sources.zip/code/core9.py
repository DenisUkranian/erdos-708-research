"""Exhaustive labelled classification of positive collision blocks in the nine-source proof."""
from collections import Counter
from itertools import combinations, combinations_with_replacement
from math import prod
import json

def classify():
    counts=Counter()
    maxima=Counter()
    pure=Counter()
    exceptions=[]
    five_vertex_patterns=[]
    for v in range(4,7):
        for low in range(v+1):
            if 3*(v-low)>9 or 3*v+low>18:
                continue
            edges=[edge for edge in combinations(range(v),2) if edge[0]<low]
            types=[()]+edges+[(i,) for i in range(v)]+[(i,i) for i in range(low)]
            positive=[]
            for n_edges in range(3,min(9,len(edges))+1):
                for subset in combinations(edges,n_edges):
                    degrees=Counter(i for edge in subset for i in edge)
                    surplus=1+n_edges-len(degrees)
                    if surplus>0:
                        losses=tuple(max(0,degrees[i]-1) for i in range(v))
                        positive.append((subset,set(degrees),surplus,losses))

            def completions(selected,sites,surplus,losses):
                for rest in combinations_with_replacement(types,9-len(selected)):
                    mult=Counter((*selected,*rest))
                    support=Counter(i for core,k in mult.items() for i in set(core) for _ in range(k))
                    if any(support[i]<3 for i in range(v)):continue
                    loops={i for i in range(low) if mult[i,i]}
                    if any(support[i]<=4 and i not in loops for i in range(low)):continue
                    counts[v,low]+=1
                    if v==5:
                        five_vertex_patterns.append((len(sites),len(selected),len(sites[0]),sorted(rest)))
                    without_loops=sum(losses[i]>=2 and i not in loops for i in range(low))
                    possible_squares=[i for i in loops if losses[i]>=2]
                    for mask in range(1<<len(possible_squares)):
                        tight={p for j,p in enumerate(possible_squares) if mask>>j&1}
                        net=surplus-without_loops-len(possible_squares)+len(tight)
                        if net<2:continue
                        if net>2:
                            exceptions.append((v,low,net,list(selected),list(rest),sorted(tight)))
                        for anchor in mult:
                            common_cap=10
                            if len(anchor)==2 and anchor[0]==anchor[1] and anchor[0] in tight:
                                common_cap=min(common_cap,mult[anchor])
                            residual=1
                            for typ,number in mult.items():
                                count=number-int(typ==anchor)
                                cap=common_cap
                                if typ!=anchor and typ in selected:
                                    cap=min(cap,number if v==5 else number+v-3)
                                if len(typ)==2 and typ[0]==typ[1] and typ[0] in tight:
                                    cap=min(cap,number)
                                if count>cap:
                                    residual=0
                                    break
                                residual*=prod(range(cap-count+1,cap+1))
                            maxima[v,low]=max(maxima[v,low],residual)
                            if anchor==():pure[v,low]=max(pure[v,low],residual)

            def visit(start,selected,sites,surplus,losses):
                if surplus>=2:completions(selected,sites,surplus,losses)
                for j in range(start,len(positive)):
                    sub,vertices,z,loss=positive[j]
                    if len(selected)+len(sub)>9 or any(len(vertices & prev)>=3 for prev in sites):continue
                    visit(j+1,selected+sub,sites+[vertices],surplus+z,tuple(a+b for a,b in zip(losses,loss)))
            visit(0,(),[],0,(0,)*v)
    assert five_vertex_patterns==[(1,6,5,[(0,0),(1,1),(2,2)])]
    assert len(exceptions)==1
    v,l,gain,edges,rest,tight=exceptions[0]
    assert (v,l,gain)==(4,3,3) and set(edges)==set(combinations(range(4),2))
    assert sorted(rest)==[(0,0),(1,1),(2,2)] and tight==[0,1,2]
    assert max(maxima.values())==16000
    return {'rows':[{'vertices':v,'low':l,'completions':c,'residual_max':maxima[v,l],'pure_anchor_residual_max':pure[v,l]}
                    for (v,l),c in sorted(counts.items())],'exception':exceptions[0],
            'five_vertex_patterns':five_vertex_patterns}

if __name__=='__main__':print(json.dumps(classify(),indent=2))
