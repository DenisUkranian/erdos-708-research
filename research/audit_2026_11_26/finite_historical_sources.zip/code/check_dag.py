"""Independent proof checker; no calls to the C++ certificate search."""
from math import gcd,prod
from functools import cache
from arithmetic import unpack_key,prime_tables,factors

def verify(lines,ps,t):
    @cache
    def integer(key):
        return prod(p**e for p,e in zip(ps,unpack_key(key,ps)))
    @cache
    def tables(m):
        return prime_tables(m,ps,t)
    known={}
    roots=set()
    def child(m,k):
        return 0 if k==0 else known[m,k]
    for line in lines:
        fields=line.split()
        if fields[0]=='R':
            m,key=map(int,fields[1:])
            assert child(m,key)<=t
            roots.add((m,key))
            continue
        m,key,k=map(int,fields[:3]);rule=fields[3];a,b=map(int,fields[4:])
        v=integer(key)
        assert 1<=k<=t and m>=1 and v>=2
        if rule=='P':
            es=unpack_key(key,ps)
            assert sum(row[e] for row,e in zip(tables(m),es))<=k
        elif rule=='O':
            assert a==v and a<=m and k==1
        elif rule=='J':
            assert gcd(integer(a),integer(b))==1 and integer(a)*integer(b)==v
            assert child(m,a)+child(m,b)<=k
        elif rule=='A':
            assert 1<=a<=m and integer(b)*a==v and child(m,b)+1<=k
            g=gcd(a,integer(b))
            if k*g>m:
                assert len(factors(g))==1
                # The prime-repair step needs the entire target to divide m!.
                for p,e in zip(ps,unpack_key(key,ps)):
                    q=m//p;valuation=0
                    while q:
                        valuation+=q;q//=p
                    assert valuation>=e
        elif rule=='S':
            assert a>=2 and 1<=b<=min(k,m//a) and v%a**b==0
            bits=sum(factors(a).count(p)<<(8*i) for i,p in enumerate(ps))
            other=key-b*bits
            assert other>=0 and integer(other)*a**b==v and child(m//a,other)<=k
        else:raise ValueError(rule)
        known[m,key]=k
    return roots
