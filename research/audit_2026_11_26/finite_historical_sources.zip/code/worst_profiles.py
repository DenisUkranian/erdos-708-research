#!/usr/bin/env python3
"""Exact maximum over all shifts of a given source set, using minimal prime profiles."""
import argparse
from collections import Counter
from itertools import product
from math import prod
from arithmetic import factors
from exact_instance import exact

def prime_profiles(M,p,d):
    q=1;e=0
    while e<d and p*q<=M:
        q*=p;e+=1
    if e==d:
        for residue in range(q):
            yield residue,q
        return
    for residue in range(q):
        offsets=range((-residue-1)%q+1,M+1,q)
        # offsets are positive, and residue + offset is a multiple of q.
        next_digits=[(-(residue+j)//q)%p for j in offsets]
        if len(next_digits)<p:
            unused=next(k for k in range(p) if k not in next_digits)
            yield residue+q*unused,p*q
        else:
            assert len(set(next_digits))==p
            for j,k in zip(offsets,next_digits):
                r=residue+q*k
                if d==e+1:
                    yield r,p*q
                    continue
                # The only elevated entry must have valuation exactly e+1.
                if (r+j)%(p*p*q)==0:r+=p*q
                assert (r+j)%(p*q)==0 and (r+j)%(p*p*q)!=0
                yield r,p*p*q

def worst(A):
    assert len(set(A))==len(A) and min(A)>=2
    M=max(A)
    demands=Counter(p for a in A for p in factors(a))
    options=[list(prime_profiles(M,p,d)) for p,d in demands.items()]
    best=-1;best_x=0;offsets=()
    for choices in product(*options):
        x=0;period=1
        for residue,q in choices:
            x+=period*((residue-x)*pow(period,-1,q)%q)
            period*=q
        selected=exact(A,x)
        if len(selected)>best:
            best,best_x,offsets=len(selected),x,selected
    return {'A':list(A),'worst_tau':best,'x':best_x,'offsets':list(offsets),
            'profiles':prod(map(len,options)),'full_product_period':prod(A)}

if __name__=='__main__':
    import json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('A',nargs='+',type=int)
    print(json.dumps(worst(parser.parse_args().A)))
